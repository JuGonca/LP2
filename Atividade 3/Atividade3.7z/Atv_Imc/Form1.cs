﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atv_Imc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        double Peso, Altura, IMC;

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            mskbxAltura.Clear();
            mskbxPeso.Clear();
            mskbxIMC.Clear();

            mskbxPeso.Focus();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //Verifica se os valores são numéricos
            if ((!double.TryParse(mskbxPeso.Text, out Peso)) || (!double.TryParse(mskbxAltura.Text, out Altura)))
            {
                MessageBox.Show("Informe um valor numérico.");
                mskbxPeso.Focus();
            }
            //Verifica se os valores são positivos
            else if(!(Peso > 0 || Altura > 0) )
            {
                MessageBox.Show("Os Números devem ser maiores que 0");
                mskbxPeso.Focus();
            }
            //Calcula o IMC
            else
            {
                IMC = Peso / Math.Pow(Altura, 2);
                IMC = Math.Round(IMC, 1);
                mskbxIMC.Text = IMC.ToString();
            }

            //Classificação dos pesos//
            if (IMC < 18.5)
                MessageBox.Show("Magreza");

            else if (IMC < 25)
                MessageBox.Show("Normal");

            else if (IMC < 30)
                MessageBox.Show("Sobrepeso");

            else if (IMC < 40)
                MessageBox.Show("Obesidade");

            else
                MessageBox.Show("Obesidade Grave");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        double num1, num2, total;

        private void txtNum1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar=='.')//MUda o ponto pela vírgura para não dar erro na conta
            {
                MessageBox.Show("Erro!");
                SendKeys.Send("{backspace}");
                SendKeys.Send(",");
            }
        }

        private void txtNum2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '.')//MUda o ponto pela vírgura para não dar erro na conta
            {
                MessageBox.Show("Erro!");
                SendKeys.Send("{backspace}");
                SendKeys.Send(",");
            }
        }

        private void btnSubt_Click(object sender, EventArgs e)
        {
            if ((!double.TryParse(txtNum1.Text, out num1)) || (!double.TryParse(txtNum2.Text, out num2)))
            {
                MessageBox.Show("Números Inválidos.");
                txtNum1.Focus();
            }

            else if (num1 < 0 || num2 < 0)
            {
                MessageBox.Show("Números devem ser maior que ou igual a 0");
                txtNum1.Focus();
            }

            else
            {
                total = num1 - num2;
                txtTotal.Text = total.ToString();
                txtNum1.Focus();
            }
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            if ((!double.TryParse(txtNum1.Text, out num1)) || (!double.TryParse(txtNum2.Text, out num2)))
            {
                MessageBox.Show("Números Inválidos.");
                txtNum1.Focus();
            }

            else if (num1 < 0 || num2 < 0)
            {
                MessageBox.Show("Números devem ser maior que ou igual a 0");
                txtNum1.Focus();
            }

            else
            {
                total = num1 * num2;
                txtTotal.Text = total.ToString();
                txtNum1.Focus();
            }
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if ((!double.TryParse(txtNum1.Text, out num1)) || (!double.TryParse(txtNum2.Text, out num2)))
            {
                MessageBox.Show("Números Inválidos.");
                txtNum1.Focus();
            }

            else if (num1 < 0 || num2 <= 0)
            {
                MessageBox.Show("Campo 1 devem ser maior que ou igual a 0. Campo 2 deve ser maior que 0");
                txtNum1.Focus();
            }

            else
            {
                total = num1 / num2;
                txtTotal.Text = total.ToString();
                txtNum1.Focus();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Clear();
            txtNum2.Clear();
            txtTotal.Clear();

            txtNum1.Focus();

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {

            if ((!double.TryParse(txtNum1.Text, out num1)) || (!double.TryParse(txtNum2.Text, out num2)))
            {
                MessageBox.Show("Números Inválidos.");
                txtNum1.Focus();
            }

            else if (num1 < 0 || num2 < 0)
            {
                MessageBox.Show("Números devem ser maior que ou igual a 0");
                txtNum1.Focus();
            }

            else
            {
                total = num1 + num2;
                txtTotal.Text = total.ToString();
                txtNum1.Focus();
            }
            
        }


    }
}
